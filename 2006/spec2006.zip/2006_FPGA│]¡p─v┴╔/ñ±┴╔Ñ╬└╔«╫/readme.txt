readme.txt :       Readme file.

testfixture.v :     Test bench includes the definition of clock 
                          period and the file names of test patterns.

triangle.v :         The input and output ports are declared in this file.

input.dat :          The input coordinates (xi, yi) of the triangle are 
                          listed in this file.
               
expect.dat :        The expect results (xo,yo) are recorded in this file.

report_xxx.txt :  This file is used to describe the materials that should 
                          be handed in by each team. The design and related file names, 
                          tool names, related specifications and others are described 
                          in this file.


